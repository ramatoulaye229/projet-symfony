<?php

namespace ContainerXQXq8dd;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder418ee = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerf2941 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties75f00 = [
        
    ];

    public function getConnection()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getConnection', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getMetadataFactory', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getExpressionBuilder', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'beginTransaction', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getCache', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getCache();
    }

    public function transactional($func)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'transactional', array('func' => $func), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->transactional($func);
    }

    public function commit()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'commit', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->commit();
    }

    public function rollback()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'rollback', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getClassMetadata', array('className' => $className), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'createQuery', array('dql' => $dql), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'createNamedQuery', array('name' => $name), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'createQueryBuilder', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'flush', array('entity' => $entity), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'clear', array('entityName' => $entityName), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->clear($entityName);
    }

    public function close()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'close', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->close();
    }

    public function persist($entity)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'persist', array('entity' => $entity), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'remove', array('entity' => $entity), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'refresh', array('entity' => $entity), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'detach', array('entity' => $entity), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'merge', array('entity' => $entity), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getRepository', array('entityName' => $entityName), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'contains', array('entity' => $entity), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getEventManager', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getConfiguration', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'isOpen', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getUnitOfWork', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getProxyFactory', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'initializeObject', array('obj' => $obj), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'getFilters', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'isFiltersStateClean', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'hasFilters', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return $this->valueHolder418ee->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerf2941 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder418ee) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder418ee = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder418ee->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, '__get', ['name' => $name], $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        if (isset(self::$publicProperties75f00[$name])) {
            return $this->valueHolder418ee->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder418ee;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder418ee;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder418ee;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder418ee;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, '__isset', array('name' => $name), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder418ee;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder418ee;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, '__unset', array('name' => $name), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder418ee;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder418ee;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, '__clone', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        $this->valueHolder418ee = clone $this->valueHolder418ee;
    }

    public function __sleep()
    {
        $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, '__sleep', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;

        return array('valueHolder418ee');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerf2941 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerf2941;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerf2941 && ($this->initializerf2941->__invoke($valueHolder418ee, $this, 'initializeProxy', array(), $this->initializerf2941) || 1) && $this->valueHolder418ee = $valueHolder418ee;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder418ee;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder418ee;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
