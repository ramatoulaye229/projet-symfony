<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProposerController extends AbstractController
{
    /**
     * @Route("/proposer", name="proposer")
     */
    public function index(): Response
    {
        return $this->render('proposer/proposer.html.twig', [
            'controller_name' => 'ProposerController',
        ]);
    }
    
}
