<?php

namespace App\Entity;

use App\Repository\ReservationRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ReservationRepository::class)
 */
class Reservation
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="datetime")
     */
    private $date_de_la_reservation;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $Etat_de_la_reservation;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateDeLaReservation(): ?\DateTimeInterface
    {
        return $this->date_de_la_reservation;
    }

    public function setDateDeLaReservation(\DateTimeInterface $date_de_la_reservation): self
    {
        $this->date_de_la_reservation = $date_de_la_reservation;

        return $this;
    }

    public function getEtatDeLaReservation(): ?string
    {
        return $this->Etat_de_la_reservation;
    }

    public function setEtatDeLaReservation(string $Etat_de_la_reservation): self
    {
        $this->Etat_de_la_reservation = $Etat_de_la_reservation;

        return $this;
    }
}
