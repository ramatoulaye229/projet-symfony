<?php

namespace App\Entity;

use App\Repository\BiensRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=BiensRepository::class)
 */
class Biens
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="text")
     */
    private $description;

    /**
     * @ORM\Column(type="string", length=40)
     */
    private $zone;

    /**
     * @ORM\Column(type="string", length=15)
     */
    private $type_usage;

    /**
     * @ORM\Column(type="integer")
     */
    private $Montant_du_loyer;

    /**
     * @ORM\Column(type="json")
     */
    private $image = [];

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getZone(): ?string
    {
        return $this->zone;
    }

    public function setZone(string $zone): self
    {
        $this->zone = $zone;

        return $this;
    }

    public function getTypeUsage(): ?string
    {
        return $this->type_usage;
    }

    public function setTypeUsage(string $type_usage): self
    {
        $this->type_usage = $type_usage;

        return $this;
    }

    public function getMontantDuLoyer(): ?int
    {
        return $this->Montant_du_loyer;
    }

    public function setMontantDuLoyer(int $Montant_du_loyer): self
    {
        $this->Montant_du_loyer = $Montant_du_loyer;

        return $this;
    }

    public function getImage(): ?array
    {
        return $this->image;
    }

    public function setImage(array $image): self
    {
        $this->image = $image;

        return $this;
    }
}
