<?php

namespace App\Repository;

use App\Entity\Bens;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Bens|null find($id, $lockMode = null, $lockVersion = null)
 * @method Bens|null findOneBy(array $criteria, array $orderBy = null)
 * @method Bens[]    findAll()
 * @method Bens[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class BensRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Bens::class);
    }

    // /**
    //  * @return Bens[] Returns an array of Bens objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('b')
            ->andWhere('b.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('b.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Bens
    {
        return $this->createQueryBuilder('b')
            ->andWhere('b.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
